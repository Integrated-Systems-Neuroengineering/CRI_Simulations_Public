import torch
import torch.nn as nn
from collections import defaultdict, OrderedDict
import pickle

def test_result(conv_layer, input_data, mapping):
    conv_result = defaultdict(int)
    input_height = input_data.size()[0]
    input_width = input_data.size()[1]

    # Calculate the convolution
    for input in mapping:
        for dest, weight in mapping[input]:
            conv_result[dest] += input_data[int(input / input_height)][input % input_width] * weight
    # Add the biases:

    for destination in conv_result:
        conv_result[destination] += conv_layer.bias[0].item()

    result_tensor = torch.zeros(len(conv_result))
    for d in conv_result:
        result_tensor[d] = conv_result[d]

    return result_tensor


def kernel_template(idx, x_loc, y_loc, feature_height, feature_width, kernel_weights):
    kernel_height = kernel_weights.size()[0]
    kernel_width = kernel_weights.size()[1]
    # print(kernel_weights)

    result = defaultdict(list)

    # Iterate through kernel width and length
    for i in range(kernel_height):
        for j in range(kernel_width):
            if i + y_loc >= 0 and j + x_loc >= 0 and i + y_loc < feature_height and j + x_loc < feature_width:
                # result.append((x_loc + y_loc + i + j, kernel_weights[i][j].item()))

                # The correct location on the input image            The idx of the target feature
                result[(i + y_loc) * feature_width + (j + x_loc)].append((idx, i, j))

    return result

def max_pool_template(start_idx, x_loc, y_loc, feature_height, feature_width, kernel_height, kernel_width):
    result = defaultdict(list)

    for i in range(kernel_height):
        for j in range(kernel_width):
            if i + y_loc >= 0 and j + x_loc >= 0 and i + y_loc < feature_height and j + x_loc < feature_width:
                # result.append((x_loc + y_loc + i + j, kernel_weights[i][j].item()))

                # The correct location on the input image            The idx of the target feature
                result[(i + y_loc) * feature_width + (j + x_loc)].append((start_idx))

    # print(kernel_weights)

    return result

def map_linear_layer(start_idx, input_size, output_size, filename):
    mapping = defaultdict(list)

    destinations = list(range(start_idx + input_size, start_idx + input_size + output_size))
    for pre in range(start_idx, start_idx + input_size):
        mapping[pre] = destinations
    
    with open (filename + '.pkl', 'wb') as f:
        pickle.dump(mapping,f)
    
    return len(mapping)

def map_output_layer(start_idx,output_size,filename):
    mapping = {}
    
    for i in range(start_idx, start_idx + output_size):
        print(i)
        mapping[i] = []
    
    with open(filename + '.pkl', 'wb') as f:
        pickle.dump(mapping, f)
    
    return len(mapping)
    

def map_maxpool_layer(start_idx, maxpool_layer, input_size, filename):
    input_channels = input_size[1]
    input_height = input_size[2]
    input_width = input_size[3]

    print(maxpool_layer.padding)
    x_pad, y_pad = maxpool_layer.padding
    x_stride, y_stride = maxpool_layer.stride
    x_kernel_length, y_kernel_length = maxpool_layer.kernel_size

    #For this layer, the number of channels should be the same
    output_kernels = input_channels
    mapping = defaultdict(list)
    new_layer_len = 0

    for y in range(-y_pad, input_height - y_kernel_length + y_pad + 1, y_stride):
        for x in range(-x_pad, input_width - x_kernel_length + x_pad + 1, x_stride):
            max_pool_graph = max_pool_template(new_layer_len, x, y, input_height, input_width, x_kernel_length, y_kernel_length)
            for i in max_pool_graph:
                if max_pool_graph[i]:
                    mapping[i] += max_pool_graph[i]
            new_layer_len += 1


    print('NEW LAYER LENGTH', new_layer_len)
    # print(len(max_pool_graph))
    # print(max_pool_graph)

    mapping = {k: v for k, v in mapping.items() if v != []}
    print(len(mapping))

    final_map = defaultdict(list)



   # Keeps track of the kernel size
    current_length = 0

    #Keeps track of the starting destination kernel
    dest_idx = len(mapping) * output_kernels + start_idx


    for channel in range(output_kernels):
        for input in mapping:
            current = []

            for dest in mapping[input]:
                current.append(dest_idx + dest)
            #print(input, current_length)
            final_map[start_idx + input + current_length] += current
        current_length += len(mapping)
        dest_idx += new_layer_len

    print(len(final_map))

    final_map = OrderedDict(sorted(final_map.items()))
    with open(filename + '.pkl', 'wb') as f:
        pickle.dump(dict(final_map), f)
    return len(final_map)




def map_conv_layer(start_idx, conv_layer, input_size,filename):
    input_channels = input_size[1]
    input_height = input_size[2]
    input_width = input_size[3]

    x_pad, y_pad = conv_layer.padding
    x_stride, y_stride = conv_layer.stride
    x_kernel_length, y_kernel_length = conv_layer.kernel_size

    output_kernels = conv_layer.weight.size()[0]

    mapping = defaultdict(list)

    new_layer_len = 0
    for y in range(-y_pad, input_height - y_kernel_length + y_pad+1, y_stride):
        for x in range(-x_pad, input_width - x_kernel_length + x_pad+1, x_stride):
            kernel_graph = kernel_template(new_layer_len, x, y, input_height, input_width, conv_layer.weight[0][0])
            print(x,y)
            for i in kernel_graph:
                if kernel_graph[i]:
                    mapping[i] += kernel_graph[i]
            new_layer_len += 1
    mapping = {k: v for k, v in mapping.items() if v != []}
    print('new_layer_len',new_layer_len)

    
    dest_idx = len(mapping) * input_channels + start_idx
    print(dest_idx)
    print(len(mapping), output_kernels, start_idx)
    # The

    # for channel in range(input_channels):

    final_map = defaultdict(list)

    current_channel = 0
    print("LEN INPUT CHANNELS: ", input_channels)
    for channel in range(input_channels):
        current_length = len(mapping) * input_channels + start_idx
        for kernel in range(output_kernels):
            print('kernel #', kernel)
            # For each input Neuron
            for input in mapping:

                # For each destination addr/weight pair
                current = []
                for dest, x, y in mapping[input]:
                    current.append(dest + current_length)

                final_map[start_idx + input + current_channel] += current

            current_length += new_layer_len
        current_channel += len(mapping)

    print(len(final_map))

    final_map = OrderedDict(sorted(final_map.items()))
    with open(filename + '.pkl', 'wb') as f:
        pickle.dump(dict(final_map), f)
    return len(final_map)


def main():
    torch.manual_seed(0)
    model = torch.hub.load('pytorch/vision:v0.6.0', 'alexnet', pretrained=True)

    model.eval()
    print(model)

    rand_img = torch.rand((1, 3, 224, 224))

    layer1 = nn.Conv2d(3, 64, kernel_size=(11, 11), stride=(4, 4), padding=(2, 2))
    layer2 = nn.Conv2d(64, 192, kernel_size=(5,5), stride=(1,1), padding=(2,2))
    layer3 = nn.Conv2d(192,384,kernel_size=(3,3),stride=(1,1),padding=(1,1))
    layer4 = nn.Conv2d(384,256,kernel_size=(3,3),stride=(1,1),padding=(1,1))
    layer5 = nn.Conv2d(256,256,kernel_size=(3,3),stride=(1,1),padding=(1,1)) 
    print(layer1.bias)

    train = True
    total_len = 0
    if train:
        #test_map = map_conv_layer(0, layer1, rand_img.size(), 'conv1')
        #total_len += map_maxpool_layer(total_len, nn.MaxPool2d(kernel_size=(3,3),stride=(2,2),padding=(0,0),dilation=1), [1,64,55,55], 'maxpool1')
        #total_len += map_conv_layer(total_len,layer2,[1,64,27,27],'conv2')
        #total_len += map_maxpool_layer(total_len,nn.MaxPool2d(kernel_size=(3,3),stride=(2,2),padding=(0,0),dilation=1), [1,192,27,27], 'maxpool2')
        #total_len += map_conv_layer(total_len,layer3,[1,192,13,13],'conv3')
        #total_len += map_conv_layer(total_len,layer4,[1,384,13,13],'conv4')
        #total_len += map_conv_layer(total_len, layer5,[1,256,13,13],'conv5')
        #total_len += map_maxpool_layer(total_len, nn.MaxPool2d(kernel_size=(3,3),stride=(2,2),padding=(0,0),dilation=1), [1, 256, 13, 13], 'maxpool3')
        #total_len+= map_linear_layer(total_len, 6 * 6 * 256, 4096,'fc1')
        #total_len+= map_linear_layer(total_len, 4096,4096, 'fc2')
        #total_len+= map_linear_layer(total_len,4096,1000,'fc3')
       	##total_len += map_output_layer(581504, 1000, 'output')
    
        #total_len += map_linear_layer(0,4096, 4096, 'h1')
        #total_len += map_linear_layer(total_len,4096,4096,'h2')
        #total_len += map_linear_layer(total_len,4096,4096,'h3')
        #total_len += map_linear_layer(total_len,4096,10,'h4')
        #total_len += map_output_layer(total_len, 10,'output')
       

        total_len += map_linear_layer(0, 2048, 2048,'h1')
        total_len += map_linear_layer(total_len, 2048, 2048,'b1')
        total_len += map_linear_layer(total_len, 2048, 2048,'h2')
        total_len += map_linear_layer(total_len, 2048, 2048,'b2')
        total_len += map_linear_layer(total_len, 2048, 2048,'h3')
        total_len += map_linear_layer(total_len, 2048, 2048,'b3')
        total_len += map_linear_layer(total_len, 2048, 2048,'h4')
        total_len += map_linear_layer(total_len, 2048, 1000,'b4')
        total_len += map_output_layer(total_len, 1000, 'output')
    
    pass



if __name__ == '__main__':
    main()
