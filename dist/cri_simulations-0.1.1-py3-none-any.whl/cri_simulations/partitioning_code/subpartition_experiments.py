import pickle
import numpy 
import metis
import time
from cri_simulations.partitioning_code.sample_network import generate_random_class_labels
import numpy as np
import sklearn
from importlib import reload


def new_estimate_hbm(adj_list, class_labels,prnt=True):
    '''
    :param G: Graph object
    :param class_labels: key is the class label, value is the list of nodes
    :return:
    '''

    #First estimate for all the neurons dumped into a single core:
    # This consists of external and internal pointer sections, and hbm
    # The external pointer section is empty

    #print(type(G))
    un_optimized_num_bits = 0

    #hbm data
    for node in range(len(adj_list)):
        un_optimized_num_bits += 32 * len(adj_list[node])

    optimized_num_bits = dict((el,0) for el in set(val for val in class_labels.values()))
    num_external_messages = [0] * len(optimized_num_bits)
    num_neurons_per_core = [0] * len(optimized_num_bits)
    #hbm data

    for node in range(len(adj_list)):
        temp_connex = [0] * len(optimized_num_bits)
        num_neurons_per_core[class_labels[node]] += 1

        # Get the number of connections going inside and outside
        for edge in adj_list[node]:
            #Located on the same core
            if class_labels[node] == class_labels[edge]:
                temp_connex[class_labels[node]] += 1

            #Located on different cores
            else:
                temp_connex[class_labels[edge]] += 1

        #print(temp_connex)

        for idx, num_connex in enumerate(temp_connex):

            #If the node we're connected to is in the same cluster
            if class_labels[node] == idx:
                optimized_num_bits[idx] += 32 * num_connex
            else:
                if num_connex >= 1:
                    num_external_messages[class_labels[node]] += 1
                    optimized_num_bits[class_labels[node]] += 32
                    optimized_num_bits[idx] += 32 * num_connex

        #print(optimized_num_bits)
    if prnt:
        print(f'Number of internal Neurons per core: {num_neurons_per_core}')
        print(f'Number of external messages: {num_external_messages}')
        print(f'External + Internal Elements in each Core: {np.add(num_external_messages, num_neurons_per_core)}')
        print(f'Unoptimized Number of bits: {un_optimized_num_bits}')
        print(f'Optimized Number of bits in each core: {optimized_num_bits}')
        print(f'Total optimized number of bits: {sum(optimized_num_bits.values())}')
        print(f'Total number of external messages: {sum(num_external_messages)}')

        print('_________________________________')

    return (sum(num_external_messages), sum(optimized_num_bits.values()))



with open('alexnetv2.pkl', 'rb') as f:
	alexnet = pickle.load(f)


with open('alexnet_partition.pkl', 'rb') as f:
	initial_partition = pickle.load(f)

assignments = [0] * 4
for key in initial_partition:
	assignments[initial_partition[key]] += 1

print(assignments)

n_partitions=4
n_cores = 8

new_labels = {}

for i in range(n_partitions):
	print("Cluster #: ", i)
	core_partition = []
	core_idx = i * 8	
	idx = 0

	old_to_new_map = {} #maps the original neuron location to new neuron location
	new_to_old_map = {} #maps the new neuron location to the original neuron location

	# Get only the keys/values that are in the i'th partition
	for j in range(len(alexnet)):
		if initial_partition[j] == i:
			core_partition.append(alexnet[j])
			old_to_new_map[j] = idx
			new_to_old_map[idx] = j
			idx += 1	

	# Remove all connections that don't go to the same core
	# Map all the connections in the destination cores to the new scheme (old_to_new)
	for idx in range(len(core_partition)):
		new_connex = []
		for connex in core_partition[idx]:
			# IS this connection in the same corei?
			if initial_partition[connex] == i:
				new_connex.append(old_to_new_map[connex])		
		core_partition[idx] = new_connex
	print("Length of the core partitioning: ", len(core_partition), i)
	print("starting partitioning")	
	start = time.time()
	G = metis.adjlist_to_metis(core_partition)
	n_cuts,membership = metis.part_graph(G,4)
	end = time.time()

	print('Partitioning finished in: ', end - start)
	class_labels = {}
	for l in range(len(membership)):
		class_labels[l] = membership[l]
		new_labels[new_to_old_map[l]] = core_idx + membership[l] 

	print('HBM Estimate for METIS Partitioning of Cluster %d' %(i))	
	new_estimate_hbm(core_partition, class_labels)
	#print('HBM Estimate for RANDOM Partitioning of Cluster %d' %(i))
	#random_labels = generate_random_class_labels(len(core_partition), 4)
	
	#new_estimate_hbm(core_partition,random_labels)	
with open('new_labels.pkl', 'wb') as f:
	pickle.dump(new_labels,f)

print(len(new_labels))
print(list(new_labels.keys())[0])
