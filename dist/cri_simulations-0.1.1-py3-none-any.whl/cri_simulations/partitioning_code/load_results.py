import pickle
import numpy as np

#res = ["0.001", "0.01", "0.1", "1"]
#res = ["0.001", "0.01", "0.1", "1"]
res = ["10000","100000", "1000000"]
#directory = "sw_results_256_2"
#res = [""]
directory = "sw_results_8"

final = [[],[],[],[],[],[],[],[],[]]
final_stds = [[],[],[],[],[],[],[],[],[]]
for i in res:
    
    with open(directory + "/results_" + i + "_" + str(True) + ".pkl", "rb") as f:
        data = pickle.load(f)

    for val,i in enumerate(data):
        final[val].append(np.mean(i))
        final_stds[val].append(np.std(i))

labels = ["f1","f2","f3","r1","r2","r3","h1","h2","h3"]
labels_stds = ["f1_std","f2_std","f3_std","r1_std","r2_std","r3_std","h1_std","h2_std","h3_std"]

print("__________________________")
for i in range(len(final)):
    print(labels[i] + "=", final[i])

print("__________________________")
for i in range(len(final)):
    print(labels_stds[i] + "=", final_stds[i])

print("__________________________")
final = [[],[],[],[],[],[],[],[],[]]

final_stds = [[],[],[],[],[],[],[],[],[]]
print("Now the False Mask")
for i in res:
    with open(directory + "/results_" + i + "_" + str(False) + ".pkl", "rb") as f:
        data = pickle.load(f)

    for val,i in enumerate(data):
        final[val].append(np.mean(i))
        final_stds[val].append(np.std(i))


for i in range(len(final)):
    print(labels[i] + "=", final[i])

print("__________________________")
for i in range(len(final)):
    print(labels_stds[i] + "=", final_stds[i])
