import numpy as np
import pickle
import metis
import pymetis
from cri_simulations.partitioning_code.estimate_hbm_v2 import new_estimate_hbm
from cri_simulations.partitioning_code.estimate_hbm_no_mask import estimate_hbm_no_mask
import itertools
import cri_simulations.partitioning_code.balanced_kmeans
from collections import defaultdict
import time


def align_2(filename, fpga_size, n, mask = True):
    n_first = n[0]

    with open(filename + "_adjacency.pkl", "rb") as f:
        adj = pickle.load(f)

    adj_new = adj.astype(np.int32).tolist()

    for row in range(len(adj)):
        new_connex = []
        for connex in range(len(adj[row])):
            new_connex.append((connex,adj_new[row][connex]))

        adj_new[row] = new_connex

    edges, partition = metis.part_graph(adj_new, n_first)
    
    #partition = balanced_kmeans.balanced_clustering(adj, n_first)
    print(partition)
    for n in range(n_first):
        assert sum(value == n for value in partition) == 8

    first_labels = {}

    print("PARTITION: ", partition)
    position = [0] * n_first
    for p in range(len(partition)):
        position[partition[p]] += 1
        first_labels[p] = 8 * partition[p] + position[partition[p]] - 1

    for key in first_labels:
        print(key, first_labels[key])

    with open(filename + ".pkl", "rb" ) as f:
        original = pickle.load(f)

    with open(filename + "_randomized_partition.pkl", "rb") as f:
        class_labels = pickle.load(f)

    print("Original Partitioning")

    #new_estimate_hbm(original,class_labels)

    first = {}
    for i in class_labels:
        first[i] = first_labels[class_labels[i]]

    
    original_adj = []
    for i in range(len(original)):
        original_adj.append(original[i])

    if mask:
        h1,h2,h3 = new_estimate_hbm(original_adj,first,num_clusters = n_first, fpga_size=fpga_size)
    if not mask:
        h1,h2,h3 = estimate_hbm_no_mask(original_adj, first, num_clusters = n_first, fpga_size = fpga_size)

    return h1,h2,h3

def align(filename, n, mask = True):
    total_time = 0
    
    n_first = n[0]
    n_second = n[1]

    with open(filename + "_adjacency.pkl", "rb") as f:
        adj = pickle.load(f)

    adj_new = adj.astype(np.int32).tolist()

    #dges,partition = pymetis.part_graph(4,adj)

    print('___________________________________')
    #weighted tuples
    for row in range(len(adj)):
        new_connex = []
        for connex in range(len(adj[row])):
            new_connex.append((connex,adj_new[row][connex]))

        adj_new[row] = new_connex

    
    total_index = 0
    new_labels = {}
    first_labels = {}
        
    print("first partition") 
    #edges, partition = metis.part_graph(adj_new, n_first)

    start = time.time()
    partition = balanced_kmeans.balanced_clustering(adj, n_first)
    end = time.time()

    print("First partition time", end - start)
    total_time += end - start

    print(partition)
    for n in range(n_first):
        assert sum(value == n for value in partition) == len(adj)/n_first

    #print("Partition using Balanced K-MEANS", partition)
    print(partition, sum(partition))
    
    print('________________________________')
    position = [0] * n_first
    
    for p in range(len(partition)):
        position[partition[p]] += 1
        first_labels[p] = 32 * partition[p] +  position[partition[p]] - 1
    
    core_idx = 0

    for i in range(n_first):

        #Iterate through the partition, find where = i, subpartition that.
        temp_adj = []
        new_to_old_map = {}
        old_to_new_map = {}
        new_idx = 0

        for index in range(len(partition)):
            
            if partition[index] == i:
                temp_adj.append(adj_new[index])
                new_to_old_map[new_idx] = index
                old_to_new_map[index] = new_idx
                new_idx += 1 
        
        print('____________________')
        # Remove all connections outside the partition
        
        for row in range(len(temp_adj)):
            temp_row = []
            balanced_temp_row = []
            for val in temp_adj[row]:
                if partition[val[0]] == i:
                    temp_row.append((old_to_new_map[val[0]], val[1]))
                    
            temp_adj[row] = temp_row

        temp_adj_matrix = np.zeros((len(temp_adj), len(temp_adj)))

        for row in range(len(temp_adj)):
            for col in temp_adj[row]:
                temp_adj_matrix[row][col[0]] = col[1]


        #subpartition = balanced_kmeans.balanced_clustering(temp_adj_matrix, n_second)  
        start = time.time()
        subedges,subpartition = metis.part_graph(temp_adj, n_second)
        end = time.time()
        print("Recursive Partitioning Times: ", end - start)
        total_time += end - start
        print(subpartition)


        for sub in range(len(subpartition)):
            new_to_old_map[sub]
            new_labels[new_to_old_map[sub]] = core_idx + subpartition[sub]

        print('___________________')
        core_idx += 4

    position = [0] * (n_first * n_second)

    for label in new_labels:
        position[new_labels[label]] += 1
        new_labels[label] = 8 * new_labels[label] + position[new_labels[label]] - 1

    print(position)
    print(new_labels)
    print("TOTAL TIME: ", total_time)

    with open(filename + ".pkl", "rb") as f:
        original = pickle.load(f)

    with open(filename + "_randomized_partition.pkl", "rb") as f:
        class_labels = pickle.load(f)


    print("original Partitioning")
    
    print("________________________")
    #new_estimate_hbm(original,class_labels)
    #new_estimate_hbm(original,class_labels)
    
    fpl = {}
    for i in class_labels:
        fpl[i] = new_labels[class_labels[i]]

    half = {}
    for i in class_labels:
        half[i] = first_labels[class_labels[i]]

    print("Full Hierarchical Partitioning")
    print("________________________")
    if mask:
        h1,h2,h3 = new_estimate_hbm(original, fpl)
   
    if not mask:
        h1,h2,h3 = estimate_hbm_no_mask(original, fpl)

    #print("Partition only into 2") 
    #print("________________________")
    #new_estimate_hbm(original, half)

    return h1,h2,h3
