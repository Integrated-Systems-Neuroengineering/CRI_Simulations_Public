import pickle
from cri_simulations.partitioning_code.load_sample_net import test_result

def verify_layer(filename):
    print(filename)
    with open("new_alexnet/" + filename + '.pkl', 'rb') as f:
        file = pickle.load(f)

    print("Length ", len(file))

    initial_key = list(file.keys())[0]
    print("Initial key,val: ", initial_key,len(file[initial_key]), file[initial_key][0:5])

    final_key = list(file.keys())[-1]
    print("Final key,val: ", final_key,len(file[final_key]), file[final_key][-5:])

verify_layer('conv1')
verify_layer('maxpool1')
verify_layer('conv2')
verify_layer('maxpool2')
verify_layer('conv3')
verify_layer('conv4')
verify_layer('conv5')
verify_layer('fc1')
verify_layer('fc2')
verify_layer('fc3')
