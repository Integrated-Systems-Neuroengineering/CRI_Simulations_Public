import numpy as np
import time
from k_means_constrained import KMeansConstrained
def nearest_neighbor_maxD(input, n_clusters):

    np.set_printoptions(linewidth=np.inf)
    print(input)
    cluster_size = int (len(input) / n_clusters) - 1
    print(cluster_size)


    distance_matrix = np.zeros((len(input), len(input)))

    for i in range(len(distance_matrix)):
        for j in range(i,len(distance_matrix)):
            distance_matrix[i][j] = np.linalg.norm(input[i] - input[j])
            distance_matrix[j][i] = np.linalg.norm(input[i] - input[j])

    max_d = np.mean(distance_matrix,axis = 0)
    max_d = np.vstack((list(range(len(max_d))), max_d)).T
    max_d = max_d[list(np.lexsort((max_d[:,0], max_d[:,1])))[::-1]]

    input = np.insert(input, 0, list(range(len(input))), axis=1)

    class_idx = 0
    class_labels = [None] * len(input)
    removed_points = np.asarray([])

    while True:

        if len(max_d) < cluster_size:
            for selected in max_d:
                print('REACHED HERE, rows remaining,', selected)
                distances = distance_matrix[int(selected[0])]
                distances = [distances[d] if class_labels[d] is not None else np.nan for d in range(len(distances))]
                class_labels[int(selected[0])] = class_labels[np.nanargmin(distances)]
            break

        selected = max_d[0]

        #distance_matrix[int(selected[0])][np.argpartition(distance_matrix[int(selected[0])], cluster_size-1)[:cluster_size-1]]
        row = distance_matrix[int(selected[0])]

        closest_points = np.argpartition(row,cluster_size )
        closest_points = [point for point in closest_points
                          if point not in removed_points and
                          point != int(selected[0])][:cluster_size]

        closest_points = np.append(closest_points, int(selected[0]))

        for point in closest_points:
            max_d = max_d[max_d[:,0].astype(int) != point]
            class_labels[int(point)] = class_idx

        class_idx += 1
        removed_points = np.append(removed_points,closest_points)
        print(int(selected[0]), closest_points)
        print(class_labels)

    print(class_labels)

    return class_labels

def get_centers(data, n_clusters):

    centers = np.zeros((n_clusters, data.shape[1]))
    for j in range(n_clusters):
        skip = 0
        while skip == 0:
            i = np.random.randint(data.shape[0])
            skip = 1
            for l in range(j - 1):
                if (data[i,:] == centers[l, :]).all():
                    skip = 0

        centers[j, :] = data[i, :]
    return centers


def balanced_kmeans_clustering(data, n_clusters):
    np.set_printoptions(linewidth=np.inf)

    n = len(data)
    minsize_cluster = np.floor(n/n_clusters)
    MSE_ITERATOR_S = []
    MSE_best = np.inf
    partition_best = 0
    number_of_iterations_distribution = np.zeros(100)
    repeats = 1
    while repeats:
        centers = get_centers(data,n_clusters)

        partition = np.zeros(n)
        partition_previous = -1
        partition_changed = 1
        kmeans_iteration_number = 0


        while((partition_changed != 0) and (kmeans_iteration_number < 100)):
            partition_previous = partition.copy()

            #kmeans assignment

            costMat = np.zeros((n,n))

            for i in range(n):
                for j in range(n):
                    costMat[i,j] = (data[j,:] - centers[(i%n_clusters),:])\
                               .dot(data[j,:] - centers[(i%n_clusters),:])

            m = Munkres()
            indexes = m.compute(costMat)


            partition = np.zeros(n)

            for i in range(n):
                if indexes[i][1] != 0:
                    partition[indexes[i][1]] = i%n_clusters

            for j in range(n_clusters):
                centers[j,:] = np.mean(data[np.where(partition == j), :])

            kmeans_iteration_number += 1

            partition_changed = np.sum(partition != partition_previous)
            print('Num elements changed: ', partition_changed)
            MSE = 0
            for i in range(n):
                MSE = MSE + ((data[i,:] - centers[int(partition[i]), :])
                         .dot(data[i,:] - centers[int(partition[i]), :]))/n

            MSE_ITERATOR_S.append(MSE)


        print(MSE < MSE_best)
        print('MSE ERROR: ', MSE)
        if MSE < MSE_best:
            MSE_best = MSE
            C_best = centers
            partition_best = partition.copy()
        else:
            repeats = False
            break

    print(partition_best)
    unique, counts = np.unique(partition_best, return_counts = True)
    print(dict(zip(unique,counts)))
    return partition_best

def balanced_clustering(data, n_clusters):
    #original_data = data.copy()
    # cluster_size = np.floor(len(data) /n_clusters)
    # places = list(range(len(data)))
    # data = np.insert(data, 0, places,axis = 1)
    # places.insert(0,0)
    # data = np.insert(data, 0, places,axis = 0)
    # data[0][0] = np.inf
    #
    # print(data)
    # #Randomly select a point
    # node = np.random.randint(1,len(data))
    # print(node)
    # print(np.where(data[:,node + 1] == 1)[0] - 1)
    print('Time for K_means: ')
    start = time.time()

    clf = KMeansConstrained(n_clusters = n_clusters, size_min = int(len(data)/n_clusters), size_max  = int(len(data)/n_clusters))
    x = clf.fit(data)

    end = time.time()
    print('Time (s): ', end - start)
    return x.labels_
