import pickle
from collections import Counter
import numpy as np

pickle_dicts = []
#for i in ['maxpool1','conv2','maxpool2','conv3','conv4','conv5','maxpool3','fc1','fc2','fc3','output']:
#for i in ['h1', 'h2', 'leoutput']:
#for i in ['h1','h2','h3','h4','output']:

for i in ['h1','b1','h2','b2','h3','b3', 'h4', 'b4', 'output']:
    with open("asrnet/" + i + '.pkl', 'rb') as f:
        pickle_dicts.append(pickle.load(f))

keys = []
for i in pickle_dicts:
	keys += list(i.keys())

print(len(keys))

print(len(set(keys)))
print([k for k,v in Counter(keys).items() if v > 1])


super_dict = {}

for d in pickle_dicts:
	for k,v in d.items():
		super_dict[k] = v


adj = []

print("LENGTH", len(super_dict))
for i in range(len(super_dict)):
    adj.append(np.array(super_dict[i]))



with open('asrnet/asrnet_final.pkl', 'wb') as f:
    pickle.dump(adj, f)


print(len(adj))
print(adj[-1])
print(adj[17384- 2048])
print(len(pickle_dicts[-1]))
