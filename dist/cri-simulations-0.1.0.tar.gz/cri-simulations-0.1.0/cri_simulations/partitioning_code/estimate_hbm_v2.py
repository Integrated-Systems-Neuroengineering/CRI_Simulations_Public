import numpy as np
from collections import OrderedDict


def new_estimate_hbm(adj_list, class_labels, cluster_size = 8, num_clusters = 4, fpga_size = 32):

    unoptimized_num_bits = 0

    unoptimized_num_bits = sum([32 * len(i) for i in adj_list])

    # Gets how many unique cores there are
    optimized_num_bits = dict((el,0) for el in set(val for val in class_labels.values()))
    num_neurons_per_core = [0] * len(optimized_num_bits)


    connections = {}

    print("OPTIMIZED NUM BITS: ", len(optimized_num_bits))
    for i in range(len(optimized_num_bits)):
        connections[i] = {"same_cluster" : 0, "different_cluster": 0, "different_fpga": 0}

    occ = 0
    for node in range(0,len(adj_list)):
        temp_connex = [0] * len(optimized_num_bits)
        num_neurons_per_core[class_labels[node]] += 1


       #Get the number of connections to each core, cluster, and different_fpga
       # Add one to each edge connection (even if it is yourself)
        for edge in adj_list[node]:
            temp_connex[class_labels[edge]] += 1

        fpga_num = 0

        core_index = class_labels[node] % cluster_size
        fpga_index = class_labels[node] % fpga_size
        source = class_labels[node]

        different_fpga = False 

        fpga_chunks = np.array_split(temp_connex, len(temp_connex)/fpga_size)
        for chunk in fpga_chunks:
            same_fpga = source >= fpga_num and source < fpga_num + fpga_size

            if same_fpga:
                cluster_chunks = np.array_split(chunk, len(chunk)/cluster_size)
                cluster_num = 0
                overall_different_cluster = False

                for cluster in cluster_chunks:

                    same_cluster_connection = False
                    different_cluster_connection = False

                    if sum(cluster) > 0:
                        if int((fpga_index + fpga_num) / cluster_size) == int((cluster_num + fpga_num) / cluster_size):
                            same_cluster_connection = True
                        else:
                            different_cluster_connection = True
                            overall_different_cluster = True

                    if same_cluster_connection:
                        #Am I only connected to my respctive core in my cluster
                        if sum(cluster) == cluster[core_index]:
                            optimized_num_bits[fpga_num + cluster_num + core_index]
                        else:
                            connections[fpga_num + cluster_num + core_index]["same_cluster"] += 1

                    if different_cluster_connection:
                        #Check if you're connected only to the respective core:
                        only_connection = False
                        if sum(cluster) == cluster[core_index]:
                            only_connection = True
                            occ += 1
                        if not only_connection:
                            connections[fpga_num + cluster_num + core_index]["same_cluster"] += 1

                    cluster_num += cluster_size
                #if there was a connection to a different cluster
                if overall_different_cluster:
                    connections[fpga_num + fpga_index]["different_cluster"] += 1
            else:
                if sum(chunk) != 0:
                    different_fpga = True
                #Check if there are only connections to the same core_index


                only_connection = False
                for i in range(len(chunk)):
                    if sum(chunk) == chunk[fpga_index]:
                        only_connection = True


                if only_connection:
                    optimized_num_bits[class_labels[node]] += 32
                else:
                    cluster_chunks = np.array_split(chunk, len(chunk)/cluster_size)
                    cluster_num = 0
                    overall_different_cluster = False
                    for cluster in cluster_chunks:

                        same_cluster_connection = False
                        different_cluster_connection = False
                        #Are there connections to this cluster?
                        if sum(cluster) > 0:
                            
                            if int((fpga_index + fpga_num) / cluster_size) == int((cluster_num + fpga_num) / cluster_size):
                                same_cluster_connection = True
                            else:
                                different_cluster_connection = True
                                overall_different_cluster = True

                        if same_cluster_connection:
                            #Am I only connected to my respctive core in my cluster
                            if sum(cluster) == cluster[core_index]:
                                optimized_num_bits[fpga_num + cluster_num + core_index]
                            else:
                                connections[fpga_num + cluster_num + core_index]["same_cluster"] += 1

                        if different_cluster_connection:
                            #Check if you're connected only to the respective core:
                            only_connection = False
                            if sum(cluster) == cluster[core_index]:
                                only_connection = True

                            if not only_connection:
                                connections[fpga_num + cluster_num + core_index]["same_cluster"] += 1

                        cluster_num += cluster_size
                    #if there was a connection to a different cluster
                    if overall_different_cluster:
                        connections[fpga_num + fpga_index]["different_cluster"] += 1
            
            fpga_num += fpga_size
        if different_fpga:
            connections[source]["different_fpga"] += 1

    print("RELAYS", occ)
    print(f'Number of internal Neurons per core: {num_neurons_per_core}')
    print(f'Unoptimized Number of bits: {unoptimized_num_bits}')
    print(f'Optimized Number of bits: {optimized_num_bits}')
    print('Message Profile:')
#    for i in connections:
#        print(i, connections[i])

    cluster_connex = []
    for i in range(int(len(connections)/cluster_size)):
        cluster_connex.append({"same_cluster" : 0, "different_cluster" : 0, "different_fpga": 0})

    for i in connections:
        cluster_connex[int(i/cluster_size)]["same_cluster"] += connections[i]["same_cluster"]
        cluster_connex[int(i/cluster_size)]["different_cluster"] += connections[i]["different_cluster"]
        cluster_connex[int(i/cluster_size)]["different_fpga"] += connections[i]["different_fpga"]

    print('_______________TOTAL______________________')
    for i in range(len(cluster_connex)):
        print(i,cluster_connex[i])

    print("Total intracluster: ", sum([i["same_cluster"] for i in cluster_connex ]))
    print("Total intercluster: ", sum([i["different_cluster"] for i in cluster_connex ]))
    print("Total intraserver: ", sum([i["different_fpga"] for i in cluster_connex ]))


    return sum([i["same_cluster"] for i in cluster_connex ]), sum([i["different_cluster"] for i in cluster_connex ]), sum([i["different_fpga"] for i in cluster_connex ]) 




