import pickle


val = [0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009]

for v in val:
    with open ("hier_files/hier_network_8_4_1000_" + str(v) + "_8" + ".pkl", "rb") as f:
        data = pickle.load(f)


    counter = 0
    for i in range(len(data)):
        
        for j in data[i]:
            if i < 32000 and j >= 32000:
                counter += 1

            elif i >=32000 and j < 32000:
                counter += 1
            print(i,j)
        break
    print(counter, len(data[i]))

    break
