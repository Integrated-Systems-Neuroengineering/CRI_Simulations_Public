import numpy as np
import pickle
import sys
import cri_simulations.partitioning_code.balanced_kmeans
def get_adjacency(filename):

    with open(filename + ".pkl", "rb") as f:
        adj = pickle.load(f)


    with open(filename + "_randomized_partition.pkl", "rb") as f:
        class_labels = pickle.load(f)


    
    optimized_num_bits = dict((el,0) for el in set(val for val in class_labels.values()))
    adj_size = len(optimized_num_bits)
    matrix = np.zeros((adj_size,adj_size))


    for node in range(len(adj)):
        used = []
        for connection in adj[node]:

            if class_labels[connection] not in used:
                matrix[class_labels[node]][class_labels[connection]] += 1 
                used.append(class_labels[connection])

    np.set_printoptions(threshold=sys.maxsize)


    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            if i == j:
                matrix[i][j] = 0

    new_matrix = matrix.copy()

    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            new_matrix[i][j] = matrix[i][j] + matrix[j][i]


    #labels =balanced_kmeans.balanced_clustering(matrix,8)
    
    #print(labels)

    with open(filename + "_adjacency.pkl", "wb") as f:
        pickle.dump(new_matrix,f)



