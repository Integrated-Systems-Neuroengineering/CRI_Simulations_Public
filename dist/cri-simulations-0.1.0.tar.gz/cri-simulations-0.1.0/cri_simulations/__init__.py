from cri_simulations.api import *
print('hello, I got inited')
