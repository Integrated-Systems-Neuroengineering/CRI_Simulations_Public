import pickle
import numpy as np


print("Results with Mask Evaluation")
for j in range(9):
    output = []
    output_std = []
    #for l in [0.01, 0.05]:
    #for l in [0.001, 0.005,0.01, 0.05, 0.1, 0.5, 1]:
    for l in [10000, 100000, 1000000]:    
        with open("sw_results_" + str(l) + "_" + str(True), "rb") as f:
            data = pickle.load(f)

        for idx,i in enumerate(data):
            if idx == j:
                output.append(np.mean(i))
#                output_std.append(np.std(i))

    print(j, output)
 #   print(j, output_std)



print("Results with NO MASK Evaluation")
for j in range(9):
    output = []
    output_std = []
    
    #for l in [0.01, 0.05]:
    #for l in [0.001, 0.005,0.01, 0.05, 0.1, 0.5, 1]:
    
    for l in [10000, 100000, 1000000]:    
        with open("sw_results_" + str(l) + "_" + str(False), "rb") as f:
            data = pickle.load(f)

        for idx,i in enumerate(data):
            if idx == j:
                output.append(np.mean(i))
#                output_std.append(np.std(i))

    print(j, output)

