import numpy as np
import random
import matplotlib.pyplot as plt
import pickle

def get_k(l, m0, m1, m2):
        return (1/(m0 + m1 * l + m2 * l**2))

def generate_pdf(index, npc, cores_per_cluster, clusters_per_fpga, l):
        neurons = npc * cores_per_cluster * clusters_per_fpga

        k = get_k(l,npc,npc*(cores_per_cluster - 1),npc * cores_per_cluster *(clusters_per_fpga - 1))


        p_internal = k
        p_cluster = k * l
        p_fpga = k * l**2


        pdf = []
        for f in range(clusters_per_fpga):
            for c in range(cores_per_cluster):
                idx = f*cores_per_cluster + c

                # Same index
                if (idx == index):
                    pdf += [p_internal] * npc

                # Same cluster
                elif int(idx/8) == int(index/8):
                    pdf += [p_cluster] * npc
                                                                                                                                                                                                                                                             # Off cluster
                else:
                    pdf += [p_fpga] * npc


        return pdf

def randomize(adj):
    random.seed(2)
    indeces = list(range(len(adj)))
    random.shuffle(indeces)
    
    old_to_new_map = {}
    for i in range(len(indeces)):
        old_to_new_map[i] = indeces[i]


    new_to_old_map = {v:k for k,v in old_to_new_map.items()}
    new_adj = []

    for i in range(len(indeces)):
        index = new_to_old_map[i]
        new_row = np.array([])

        for j in adj[index]:
            new_row = np.append(new_row, old_to_new_map[j]).astype(int)

        new_adj.append(new_row)


    return new_adj


def gen_network(num_groups, npc, cores_per_cluster, clusters_per_fpga,l):
        nodes = []

        for group_idx in range(num_groups):
            print(group_idx)
            pdf = generate_pdf(group_idx, npc, cores_per_cluster, clusters_per_fpga,l)

            for neuron in range(npc):
                num_connections = random.randint(0,128)
                connex = np.random.choice(npc * cores_per_cluster * clusters_per_fpga, num_connections, p=pdf,replace=False)
                nodes.append(connex)

        return nodes


def old_create_network(neurons_per_core, cores_per_cluster, clusters_per_fpga, fpgas_per_server, l):
    num_nodes = cores_per_cluster * clusters_per_fpga 
    adj = gen_network(num_nodes, neurons_per_core, cores_per_cluster, clusters_per_fpga, l)

    adj = randomize(adj)
    print(len(adj))

    print("LENGTH")
    with open ('hier_files/hier_network_8_4' + '_' + str(neurons_per_core) + '_' + str(l)  + "_" + str(fpgas_per_server) +  '.pkl', 'wb') as f:
        pickle.dump(adj,f)

