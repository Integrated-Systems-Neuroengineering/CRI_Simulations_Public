# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cri_simulations',
 'cri_simulations.FPGA_Execution',
 'cri_simulations.partitioning_code']

package_data = \
{'': ['*']}

install_requires = \
['PyMetis>=2020.1,<2021.0',
 'bidict>=0.22.0,<0.23.0',
 'click>=8.1.3,<9.0.0',
 'confuse>=1.7.0,<2.0.0',
 'fbpca>=1.0,<2.0',
 'k-means-constrained>=0.7.1,<0.8.0',
 'matplotlib>=3.5.2,<4.0.0',
 'metis>=0.2a5,<0.3',
 'networkx>=2.8.3,<3.0.0',
 'numpy>=1.18',
 'scipy>=1.8.1,<2.0.0',
 'sklearn>=0.0,<0.1']

setup_kwargs = {
    'name': 'cri-simulations',
    'version': '0.1.1',
    'description': 'Software for interacting with the CRI neuromorphic hardware',
    'long_description': None,
    'author': 'Justin Frank',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
