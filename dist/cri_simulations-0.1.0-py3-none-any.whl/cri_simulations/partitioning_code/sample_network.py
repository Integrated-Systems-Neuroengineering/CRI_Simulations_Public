import numpy as np

import networkx as nx
import matplotlib.pyplot as plt
from networkx.drawing.nx_agraph import graphviz_layout
from itertools import product
from scipy.linalg import fractional_matrix_power
import cri_simulations.partitioning_code.balanced_kmeans
from fbpca import diffsnorm, pca
import time
#from k_means_constrained import KMeansConstrained
from sklearn.manifold import Isomap
from sklearn.decomposition import PCA
import random
from collections import OrderedDict

def generate_NN_graph(layers : list, display = False):

    G = nx.DiGraph()
    neuron_index = 0

    for layer in range(len(layers) - 1):
       for neuron in range(layers[layer]):
           for connec in range(layers[layer + 1]):
               G.add_edges_from([(neuron + neuron_index, connec + neuron_index + layers[layer])])

       neuron_index += layers[layer]
    
    if display:
        pos = graphviz_layout(G, prog='dot', args="-Grankdir=LR")
        nx.draw(G,with_labels=True,pos=pos, font_weight='bold')
        plt.show()
    return G

def generate_biased_random_graph(n = 5, p = 0.2, p_between= 0.8, draw = False):
    '''
    Generates a random graph that has some biased connections
    :param n: number of nodes in each cluster
    :param p: probability inter-connection
    :param p_between: probability of intra connection
    :param draw: whether to draw the graph in matplotlib
    :return: a Graph object
    '''

    G1 = nx.fast_gnp_random_graph(n,p,seed = 10,directed=True)
    G2 = nx.fast_gnp_random_graph(n,p,seed = 2,directed=True)

    combined = nx.DiGraph()
    g1 = G1.nodes()
    g2 = [n + node for node in G2.nodes()]
    combined.add_nodes_from(g1)
    combined.add_edges_from(G1.edges())
    combined.add_nodes_from(g2)
    combined.add_edges_from([(n + u, n + v) for u,v in G2.edges()])

    combined.add_edges_from([(u,v) for u,v in product(g1,g2) if np.random.rand() < p_between])
    combined.add_edges_from([(u,v) for u,v in product(g2,g1) if np.random.rand() < p_between])

    if draw:
        pos = nx.spring_layout(combined)
        nx.draw_networkx_nodes(combined, pos=pos, nodelist=g1, node_color='r')
        nx.draw_networkx_nodes(combined, pos=pos, nodelist=g2, node_color='b')
        nx.draw_networkx_edges(combined, pos=pos)
        nx.draw_networkx_labels(combined, pos = pos)
        plt.show()

    return combined

def generate_random_graph(n = 10, p = 0.2):
    G = nx.fast_gnp_random_graph(n,p,directed=True)
    #pos = nx.spring_layout(G)
    #nx.draw_networkx_nodes(G, pos=pos,  node_color='r')
    #nx.draw_networkx_edges(G, pos=pos)
   # nx.draw_networkx_labels(G, pos = pos)
    #plt.show()
    return G

def generate_small_world_graph(n = 10, k = 2, p = 0.5, display = True):
    G = nx.watts_strogatz_graph(n,k,p)
    G = G.to_directed()

    if display:
        pos = nx.spring_layout(G)
        nx.draw_networkx_nodes(G, pos=pos, node_color='r')
        nx.draw_networkx_edges(G, pos=pos)
        nx.draw_networkx_labels(G, pos=pos)
        plt.show()

    return G

def generate_scale_free(n = 10, display = False):
    G = nx.scale_free_graph(n)


    if display:
        pos = nx.spring_layout(G)
        nx.draw_networkx_nodes(G, pos=pos, node_color='r')
        nx.draw_networkx_edges(G, pos=pos)
        nx.draw_networkx_labels(G, pos=pos)
        plt.show()

    return G


def generate_random_class_labels(num_nodes, num_classes):

    # Generates random class labels to test hbm memory consumption
    class_labels = {}

    #Create random arrangment of num_nodes/2 1's and 0s
    arr = list(range(num_classes))
    arr = np.random.choice(arr, num_nodes)

    for i in range(num_nodes):
        class_labels[i] = int(arr[i])
    return class_labels

def generate_true_class_labels(layers):
    cls = 0
    class_labels = {}
    index = 0
    for i in range(len(layers)):
        for j in range((layers[i])):
            class_labels[index] = cls
            index += 1
        cls += 1

    return class_labels

def nishantOptimization(G, n_clusters, same_size = True):
    np.set_printoptions(linewidth=np.inf)

    Adj = np.asarray(nx.to_numpy_matrix(G,nodelist=sorted(G.nodes())))

    normalized_adjacency = [row/np.linalg.norm(row) if sum(row) != 0 else row for row in Adj]
    normalized_adjacency = np.stack(normalized_adjacency, axis = 0)
    import balanced_kmeans

    #labels = balanced_kmeans.balanced_kmeans_clustering(normalized_adjacency, n_clusters)
    labels = balanced_kmeans.balanced_clustering(Adj, n_clusters)


    class_labels = {}

    for idx, label in enumerate(labels):
        class_labels[idx] = int(label)

    #print(class_labels)
    return class_labels

def adj_list(G,n_clusters):
    l = {}
    for line in nx.generate_adjlist(G):
        s = line.split(' ')
        l[int(s[0])] = [int(i) for i in set(s[1:])]

    #print(l)
    cluster_size = int(len(l.keys())/n_clusters)
    remain = len(l.keys()) % n_clusters

    clusters_created = 0
    class_labels = {}

    start = time.time()

    while True:
        #print('l ', l)
        r = random.choice(list(l.keys()))
        temp = {}

        for i in l.keys():
            a = set(l[r])
            b = set(l[i])
            if len(a.union(b)) == 0:
                temp[i] = 0
            else:
                temp[i] = len(a.intersection(b))/len(a.union(b))

        temp = sorted(temp, key=temp.get, reverse=True)

        for i,val in enumerate(temp):
            class_labels[val] = clusters_created
            del l[val]

            if i == cluster_size - 1 + int(remain != 0):
                clusters_created += 1

                if remain != 0:
                    remain = remain - 1
                break

        if clusters_created == n_clusters:
            break

    end = time.time()

    #print('Time (s): ', end - start)

    #print(class_labels)
    return class_labels, end-start


def adj_list_v2(G,n_clusters):
    l = {}
    for line in nx.generate_adjlist(G):
        s = line.split(' ')
        l[int(s[0])] = [int(i) for i in set(s[1:])]

    # print(l)
    cluster_size = int(len(l.keys()) / n_clusters)
    remain = len(l.keys()) % n_clusters

    class_labels = {}

    start = time.time()

    centers = random.sample(list(l.keys()), n_clusters)

    print('centers ', centers)
    # delete the center from the list to be partitioned

    center_distances = []

    center_idx = 0

    #Compute the jaccard similarity between the center and all other neurons:
    for center in centers:
        temp = OrderedDict()
        #print(l[center])
        for i in l.keys():
            a = set(l[center])
            b = set(l[i])

            if len(a.union(b)) == 0:
                temp[i] = 0
            else:

                temp[i] = len(a.intersection(b)) / len(a.union(b))
        #print(temp)
        temp = OrderedDict(sorted(temp.items(), key =lambda x:x[1],reverse=True))
        #print(temp)
        del temp[center]
        class_labels[center] = center_idx
        center_idx += 1
        center_distances.append(temp)

    delete_list = []
    completed_list = [0] * n_clusters

    while sum(completed_list) != len(completed_list):
        center_idx = 0


        for center in centers:
            for d in delete_list:
                center_distances[center_idx].pop(d,'None')


            #print('Center %d distances: '%(center_idx), center_distances[center_idx])

            #Check if the list is empty:
            if center_distances[center_idx]:
                node = next(iter(center_distances[center_idx]))
                #print(node)
                delete_list.append(node)
                class_labels[node] = center_idx
            else:
                completed_list[center_idx] += 1
            center_idx += 1


        #print(class_labels)









    end = time.time()

    return class_labels, end-start

def di_sim_optimization(G, n_clusters):
    Adj = np.asarray(nx.to_numpy_matrix(G,nodelist=sorted(G.nodes())))

    #Regularization parameter
    tau = np.mean([node[1] for node in list(G.out_degree(G.nodes()))])
    tau = 0
    #P and O matrices
    #print(np.sum(Adj,0), np.sum(Adj,1))
    P = np.diag(np.sum(Adj,0) + tau)
    O = np.diag(np.sum(Adj,1) + tau)

    laplacian = (fractional_matrix_power(O, -0.5).dot(Adj)).dot(fractional_matrix_power(P,-0.5))
    #print('time for numpy')
    #start = time.time()

    #u,s,v = np.linalg.svd(Adj,full_matrices=False)
    #end = time.time()
    #print(u.shape, s.shape, v.shape)
    #print('Time (s): ', end - start)
    print('time for facebook')
    start = time.time()
    u,s,v = pca(Adj, n_clusters, False)
    end = time.time()

    print('Time (s): ', end - start)
    print(u.shape, s.shape, v.shape)


    left_singular = u[:,:n_clusters]
    right_singular = v[:n_clusters,:]

    # norm_left = np.linalg.norm(left_singular, axis = 0)
    # norm_right = np.linalg.norm(right_singular, axis = 1)
    # normalized_left_singular  = np.divide(left_singular, norm_left )
    # normalized_right_singular = np.divide(right_singular.T,norm_right)

    input = np.concatenate((left_singular, right_singular.T), axis = 1)
    labels = balanced_kmeans.balanced_clustering(input, n_clusters)
    print(input.shape)
    # Generate the class labels in a dictionary
    class_labels = {}

    for idx,label in enumerate(labels):
        class_labels[idx] = label

    print(class_labels)
    unique, counts = np.unique(labels, return_counts=True)
    print(dict(zip(unique, counts)))
    return class_labels

def PCA_transform (G, n_clusters):
    Adj = np.asarray(nx.to_numpy_matrix(G, nodelist=sorted(G.nodes())))

    print('Time for PCA')
    start = time.time()

    embedding = PCA(n_components=2)
    input = embedding.fit_transform(Adj)

    end = time.time()
    print('Time (s): ', end - start)
    print(input.shape)

    print('Time for K_means: ')
    start = time.time()

    clf = KMeansConstrained(n_clusters=n_clusters, size_min=int(len(input) / n_clusters) - 1,
                            size_max=int(len(input) / n_clusters) + 1)
    fit = clf.fit(input)
    labels = fit.labels_
    end = time.time()
    print('Time (s): ', end - start)
    class_labels = {}

    for idx, label in enumerate(labels):
        class_labels[idx] = label

    unique, counts = np.unique(labels, return_counts=True)
    return class_labels

def MDS_transform (G, n_clusters):
    Adj = np.asarray(nx.to_numpy_matrix(G, nodelist=sorted(G.nodes())))

    print('Time for MDS')
    start = time.time()

    embedding = MDS(n_components=2)
    input = embedding.fit_transform(Adj)

    end = time.time()
    print('Time (s): ', end - start)
    print(input.shape)

    print('Time for K_means: ')
    start = time.time()

    clf = KMeansConstrained(n_clusters=n_clusters, size_min=int(len(input) / n_clusters) - 1,
                            size_max=int(len(input) / n_clusters) + 1)
    fit = clf.fit(input)
    labels = fit.labels_
    end = time.time()
    print('Time (s): ', end - start)
    class_labels = {}

    for idx, label in enumerate(labels):
        class_labels[idx] = label

    unique, counts = np.unique(labels, return_counts=True)
    return class_labels

def isomap(G, n_clusters):
    Adj = np.asarray(nx.to_numpy_matrix(G,nodelist=sorted(G.nodes())))


    #print('Time for isomap')
    start = time.time()

    embedding = Isomap(n_components=2)
    embedding.fit(Adj[:1000])
    input = embedding.transform(Adj)
    #input = embedding.fit_transform(Adj)

    end = time.time()
    #print('Time (s): ', end - start)
    #print(input.shape)


    #print('Time for K_means: ')
    start = time.time()

    clf = KMeansConstrained(n_clusters=n_clusters, size_min=int(len(input) / n_clusters) - 1,
                            size_max=int(len(input) / n_clusters) + 1)
    fit = clf.fit(input)
    labels = fit.labels_
    end = time.time()
    #print('Time (s): ', end - start)
    class_labels = {}

    for idx, label in enumerate(labels):
        class_labels[idx] = label

    unique, counts = np.unique(labels, return_counts=True)
    return class_labels, end-start



def di_sim_v2(G, n_clusters):
    Adj = np.asarray(nx.to_numpy_matrix(G,nodelist=sorted(G.nodes())))
    first_iter = True


    print('time for facebook singular decomp')
    start = time.time()
    u, s, v = pca(Adj, n_clusters, False)
    end = time.time()

    print('Time (s): ', end - start)
    left_singular = u[:, :n_clusters]
    right_singular = v[:n_clusters, :]

    input = np.concatenate((left_singular, right_singular.T), axis=1)
    print('Time for K_means: ')
    start = time.time()

    clf = KMeansConstrained(n_clusters=n_clusters, size_min=int(len(input) / n_clusters) - 1,
                            size_max=int(len(input) / n_clusters) + 1)
    fit = clf.fit(input)
    labels = fit.labels_
    end = time.time()
    print('Time (s): ', end - start)



    # Generate the class labels in a dictionary
    class_labels = {}

    for idx, label in enumerate(labels):
        class_labels[idx] = label

    unique, counts = np.unique(labels, return_counts=True)
    return class_labels



def balanced_ml_insights(G, n_clusters):
    Adj = np.asarray(nx.to_numpy_matrix(G, nodelist=sorted(G.nodes())))
    # from mlinsights.mlmodel import KMeansL1L2
    # kml1 = KMeansL1L2(n_clusters, norm='L1')
    # kml1.fit(Adj)

def metis_partition(G, n_clusters):
    import pymetis

    G = G.to_undirected()
    adjacency_list = []
    class_labels = {}


    for node in G.nodes():
        adjacency_list.append(np.array(G.neighbors(node)))

    start = time.time()
    n_cuts,membership = pymetis.part_graph(n_clusters,adjacency=adjacency_list)
    end = time.time()


    #print(membership)

    for i in range(len(membership)):
        class_labels[i] = membership[i]
    #G.graph['edge_weight_attr'] = 'weight'
    #G = metis.networkx_to_metis(G)


    #print(G)


    # (edgecuts, parts) = metis.part_graph(G, nparts = 2, recursive=True)
    #
    # print(edgecuts)
    # print(parts)

    # G = metis.example_networkx()
    # (edgecuts, parts) = metis.part_graph(G, 3)
    # print(edgecuts, parts)

    return (class_labels, end-start)


def estimate_hbm(G, class_labels,prnt=True):
    '''

    :param G: Graph object
    :param class_labels: key is the class label, value is the list of nodes
    :return:
    '''

    #First estimate for all the neurons dumped into a single core:
    # This consists of external and internal pointer sections, and hbm
    # The external pointer section is empty

    #print(type(G))
    un_optimized_num_bits = 0

    #hbm data
    for node in G.nodes():
        un_optimized_num_bits += 32 * len(G.out_edges(node))

    optimized_num_bits = dict((el,0) for el in set(val for val in class_labels.values()))
    num_external_messages = [0] * len(optimized_num_bits)
    num_neurons_per_core = [0] * len(optimized_num_bits)
    #hbm data

    for node in G.nodes():
        temp_connex = [0] * len(optimized_num_bits)
        num_neurons_per_core[class_labels[node]] += 1

        # Get the number of connections going inside and outside
        for edge in G.out_edges(node):
            #Located on the same core
            if class_labels[edge[0]] == class_labels[edge[1]]:
                temp_connex[class_labels[edge[0]]] += 1

            #Located on different cores
            else:
                temp_connex[class_labels[edge[1]]] += 1

        #print(temp_connex)

        for idx, num_connex in enumerate(temp_connex):

            #If the node we're connected to is in the same cluster
            if class_labels[node] == idx:
                optimized_num_bits[idx] += 32 * num_connex
            else:
                if num_connex >= 1:
                    num_external_messages[class_labels[node]] += 1
                    optimized_num_bits[class_labels[node]] += 32
                    optimized_num_bits[idx] += 32 * num_connex

        #print(optimized_num_bits)
    if prnt:
        print(f'Number of internal Neurons per core: {num_neurons_per_core}')
        print(f'Number of external messages: {num_external_messages}')
        print(f'External + Internal Elements in each Core: {np.add(num_external_messages, num_neurons_per_core)}')
        print(f'Unoptimized Number of bits: {un_optimized_num_bits}')
        print(f'Optimized Number of bits in each core: {optimized_num_bits}')
        print(f'Total optimized number of bits: {sum(optimized_num_bits.values())}')
        print(f'Total number of external messages: {sum(num_external_messages)}')

        print('_________________________________')

    return (sum(num_external_messages), sum(optimized_num_bits.values()))



def main():
    random.seed(42)
    #np.random.seed(22)
    num_nodes = 10
    num_classes = 2
    nn_nodes = [784,2048,2028,2048,10]


    #Combined = generate_NN_graph(nn_nodes)
    #Combined = generate_small_world_graph(num_nodes,2,0.2,display=True)

    #
    # with open('../Compiler Code/small_world.txt', 'w') as f:
    #     for u,v,_ in Combined.edges(data=True):
    #          f.write('%d,%d,%f\n'%(u,v,random.uniform(0,1)))
    #metis_class_labels, t = metis_partition(Combined, num_classes)

    #Adj_class_labels, t = adj_list(Combined, num_classes)


   #
   #
   #  #Combined = generate_scale_free(num_nodes,display=False)
   #  #print(metis(Combined, num_classes))
   #
   #  #nishant_class_labels = nishantOptimization(Combined,num_classes)
   #  #di_sim_class_labels = di_sim_v2(Combined,num_classes)
   #  #isomap_class_labels = isomap(Combined,num_classes)
   #  #MDS_class_labels = MDS_transform(Combined,num_classes)
   #  #PCA_class_labels = PCA_transform(Combined, num_classes)
   #  #true_class_labels = generate_true_class_labels(nn_nodes)
   #
   #  #print('Results with Nishants Partitioning Algorithm:' )
   #  #estimate_hbm(Combined, nishant_class_labels)
   #
   #  ##print('Results with di-sim Partitioning Algorithm:')
   #  #estimate_hbm(Combined, di_sim_class_labels)
   #  #
   #  # print('Results with ISOMAP')
   #  # estimate_hbm(Combined, isomap_class_labels)
   #  #
   #  # print('Results with PCA')
   #  # estimate_hbm(Combined,PCA_class_labels)
   #  #

    c = [4]
    #g = [1000,5000,10000,20000]
    g = [20000]
    #
    # c = [2]
    # g = [500]


    for graph_size in g:
        #Combined = generate_small_world_graph(graph_size, 2, 0.5, display=False)
        Combined = generate_scale_free(graph_size,display=False)
        #Combined = generate_NN_graph(nn_nodes)

        for n_clusters in c:
            print('num_clusters, graph size: %d %d'%(n_clusters,graph_size))
            times = []
            rand_vals = []
            adj_vals = []
            for i in range(10):
                Adj_class_labels, t = metis_partition(Combined, n_clusters)
                times.append(t)
                random_class_labels = generate_random_class_labels(graph_size,n_clusters)

                #print('Results with Random partitioning:')
                rand_vals.append(estimate_hbm(Combined,random_class_labels,prnt=False))
                #print('Result with Testing Partitioning')
                adj_vals.append(estimate_hbm(Combined,Adj_class_labels,prnt=False))

            #print(rand_vals)
            #print(adj_vals)
            #print(times)

            p_saved_messages =  []
            p_saved_bits = []

            for j in range(len(rand_vals)):
                p_saved_bits.append(1 - adj_vals[j][1]/rand_vals[j][1])
                p_saved_messages.append(1 - adj_vals[j][0]/rand_vals[j][0])
            print(np.mean(p_saved_bits))
            print('Statistics for bits saved: Mean: {}, Std {}'.format(np.round(np.mean(p_saved_bits),5) * 100, np.round(np.std(p_saved_bits),5) * 100))
            print('Statistics for external messages saved:  Mean: {}, Std {}'.format( np.round(np.mean(p_saved_messages),5) * 100, np.round(np.std(p_saved_messages),5) * 100))
            print('Statistics for time: ', np.mean(times), np.std(times))
   #
   #
   # #print('Results with MDS')
   #  #estimate_hbm(Combined, MDS_class_labels)

if __name__ == '__main__':
    main()
