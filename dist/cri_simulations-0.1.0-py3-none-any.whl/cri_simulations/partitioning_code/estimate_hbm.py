import numpy as np
from collections import OrderedDict


def new_estimate_hbm(adj_list, class_labels, cluster_size = 8, num_clusters = 4, num_fpgas = 1, prnt = False):
    
    unoptimized_num_bits = 0
    for node in range(len(adj_list)):
        unoptimized_num_bits += 32 * len(adj_list[node])
   

    optimized_num_bits = dict((el,0) for el in set(val for val in class_labels.values()))
    num_external_messages = [0] * len(optimized_num_bits)
    num_neurons_per_core = [0] * len(optimized_num_bits)

    connections = {}

    print("OPTIMIZED NUM BITS: ", len(optimized_num_bits))
    for i in range(len(optimized_num_bits)):
        connections[i] = {"same" : 0, "different": 0}


    for node in range(len(adj_list)):
        temp_connex = [0] * len(optimized_num_bits) 
        num_neurons_per_core[class_labels[node]] += 1
        

        #Get the number of connections to each core and cluster
        for edge in adj_list[node]:
            # Add one to each edge connection (even if it is yourself)
            temp_connex[class_labels[edge]] += 1
            
        # Look at the connections to each class
        cluster_num = 0
        core_index = class_labels[node] % cluster_size # Source core index in the cluster

        if max(temp_connex[:class_labels[node]] + temp_connex[(class_labels[node] + 1):]) > 0:
            connections[class_labels[node]]["different"] += 1
            optimized_num_bits[class_labels[node]] += 32

  #      print('TEMP CONNEX', temp_connex, class_labels[node])
        while temp_connex:
            same_cluster_connection = False
            different_cluster_connection = False
            same_cluster = class_labels[node] >= cluster_num and class_labels[node] < cluster_num + cluster_size

            # Get the connections to each core in a cluster
            cluster_connex = temp_connex[0:cluster_size]

            # Iterate through the connections in a cluster
            for idx, num_connex in enumerate(cluster_connex):
                current_core = cluster_num + idx
               
                if num_connex > 0:
                    optimized_num_bits[current_core] += 32 * num_connex

                    if same_cluster and idx != core_index:
                        same_cluster_connection = True
                    elif not same_cluster:
                        different_cluster_connection = True
                    

                    
            # To same cluster, one external message to same cluster. To different cluster
            # one external message to different cluster, and one from there to same cluster

            if same_cluster_connection:
                optimized_num_bits[class_labels[node]] += 32
                connections[class_labels[node]]["same"] += 1
            if different_cluster_connection:
                #check if it was connected to respective core cluster only (no need for extra bits)
                only_core = True
                for ci,val in enumerate(cluster_connex):
                    if ci != core_index and val > 0:
                        only_core = False
                
                if not only_core:
                    optimized_num_bits[core_index + cluster_num] += 32
                    connections[core_index + cluster_num]["same"] += 1

            same_cluster = False
            del temp_connex[0:cluster_size]
            cluster_num += cluster_size
        


        
    print(f'Number of internal Neurons per core: {num_neurons_per_core}')
    print(f'Unoptimized Number of bits: {unoptimized_num_bits}')
    print(f'Optimized Number of bits: {optimized_num_bits}')
    print('Message Profile:')
    
    if prnt:
        for i in connections:
            print(i, connections[i])

    cluster_connex = []
    for i in range(num_clusters):
        cluster_connex.append({"same" : 0, "different" : 0})

    for i in connections:
        cluster_connex[int(i/cluster_size)]["same"] += connections[i]["same"]
        cluster_connex[int(i/cluster_size)]["different"] += connections[i]["different"]

    print('_______________TOTAL______________________')
    if prnt:
        for i in range(len(cluster_connex)):
            print(i,cluster_connex[i])

    intra = sum([i["same"] for i in cluster_connex])
    inter = sum([i["different"] for i in cluster_connex])
    print("Total intracluster: ", intra)
    print("Total intercluster: ", inter)

    return intra,inter
        





