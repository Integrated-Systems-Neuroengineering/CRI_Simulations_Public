import random
from collections import defaultdict
import numpy as np
import networkx as nx
import pickle
from ast import literal_eval
class AdjListEntry:
    def __init__(self, node, adjacent):
        self.node = node
        # a list of adjacent nodes
        self.adjacent = adjacent

    def __str__(self):
        return "{} -> {}".format(self.node, str(self.adjacent))


def create_scale_free_data(n_rows=5000):
    data = []
    G = nx.watts_strogatz_graph(n_rows, 50, 0.5)
    for node in G.nodes():
        adjacent = []
        for edge in G.edges(node):
            # No need to append weight since it doesn't affect placement decisions
            adjacent.append(int(edge[1]))
        data.append(AdjListEntry(node, adjacent))
    return data

def load_data_2(filename):
    new_data = []
    with open (filename,'rb') as f:
        data = pickle.load(f)
    

    for i in range(len(data)):
        new_data.append(AdjListEntry(i,data[i]))

    return new_data

def load_data():
   ax = None
   axons = {}
   connections = {}
   
   with open('small_world/small_world_10000_10_0.5.pkl', 'r') as f:
      for line in f:
         if not line.startswith('#'):
            if 'axons' in line.lower():
               ax = True
            elif 'neurons' in line.lower():
               ax = False
            else:
               pre, post = line.split(':')
               weights = literal_eval(post.strip())
               weights = [(int(i[0]), float(i[1])) for i in weights]
               if ax:
                  axons[int(pre.strip())] = weights
               else:
                  connections[int(pre.strip())] = weights   
 
   data = []
   row = 0
   for node in axons:
       adjacent = []
       for edge in connections[node]:
           if edge != (0,0,0):
              adjacent.append(edge[0])
       data.append(AdjListEntry(row,adjacent))
       row += 1
   print('placing %s Neurons'%str(len(data)))
   return data

def create_random_data(n_rows=10, max_fanout=256):
    data = []
    avg_connections = random.randint(0, max_fanout)

    for row in range(n_rows):
        row_data = random.sample(range(n_rows-1), avg_connections)
        data.append(AdjListEntry(row, row_data))
    return data


class Column:
    def __init__(self, neurons):
        self.neurons = neurons

    def total_conflict(self, neuron, conflicts):
        total = 0
        for c_neuron in self.neurons:
            key = [c_neuron, neuron]
            key.sort()
            total += conflicts[tuple(key)]
        return total


class Placement:
    """
    Makes it easier to populate rows and place the weights in the correct column after deciding on an output
    neuron placement.
    """

    def __init__(self, num_cols):
        self.rows = []
        self.num_cols = num_cols
        self.neuron_map = {}
        self.column_map = {}
        self.old_to_new_map = {}
        for i in range(self.num_cols):
            self.column_map[i] = Column([])

    def fill_columns(self):
        s = sum([len(self.column_map[i].neurons) for i in range(self.num_cols)]) + 1
        print(s)
        m = max([len(self.column_map[i].neurons) for i in range(self.num_cols)])

        for i in range(self.num_cols):
            while(len(self.column_map[i].neurons)) < m:
                self.column_map[i].neurons.append(s)
                self.neuron_map[s] = i
                s+=1


    def get_column_lengths(self):
        lens = []
        for i in range(self.num_cols):
            lens.append(len(self.column_map[i].neurons))
        return lens

    def print_assignments(self):
        for i in range(self.num_cols):
            print(i,': ',self.column_map[i].neurons,'\n')

    def create_mapping(self):
        for i in range(self.num_cols):
            for j in range(len(self.column_map[i].neurons)):
                self.old_to_new_map[self.column_map[i].neurons[j]] = j * 8 + i
        return self.old_to_new_map


    def populate_for_input_neuron(self, outgoing_weights):
        """
        Adds all the |outgoing_weights| to a fresh row and in the column for their destination neuron. On conflict,
        it creates another row.
        """
        rows = []
        for w in outgoing_weights:
            #w = self.old_to_new_map[w]
            depth = 0
            while True:
                # Check if we need to create another row
                if depth == len(rows):
                    rows.append([None] * self.num_cols)
                row = rows[depth]

                # Look for an empty slot to place the weight
                if w not in self.neuron_map:
                    raise ValueError(f'destination node not found in col map: {w}')
                dest_node_col = self.neuron_map[w]
                if row[dest_node_col] is None:
                    row[dest_node_col] = w
                    break
                depth += 1
        added_rows = len(rows)
        self.rows.extend(rows)
        return added_rows

    def assign_col(self, neuron, col):
        if col < 0 or col >= self.num_cols:
            raise IndexError(f'cannot assign to col {col}, valid is 0 to {self.num_cols - 1}')
        self.neuron_map[neuron] = col
        self.column_map[col].neurons.append(neuron)

    def get_row_num(self):
        return len(self.rows)

    def print_rows(self,length = None):
        if not length:
            end = len(self.rows)
        else:
            end = length
        for r, row in enumerate(self.rows):
            if r == length:
                break

            clean = []
            for w in row:
                if w is None:
                    clean.append('_')
                else:
                    clean.append(w)
            format_string = " | ".join(["{:^5}"] * self.num_cols)
            print(format_string.format(*clean))


def characterize_conflicts(graph):
    conflicts = defaultdict(int)
    global_conflicts = defaultdict(int)

    for entry in graph:
        if entry.node not in global_conflicts:
            global_conflicts[entry.node] = 0

        for (i, a) in enumerate(entry.adjacent):
            for b in entry.adjacent[i + 1:]:
                key = [a, b]
                key.sort()

                conflicts[tuple(key)] += 1


            global_conflicts[a] += 1



    return conflicts, global_conflicts


def create_placement(conflicts, global_conflicts, num_cols):
    cols = [Column([]) for _ in range(num_cols)]
    for n, _ in sorted(global_conflicts.items(), key=lambda x: x[1], reverse=True):
        # Find the column with the least number of conflicts
        col_conflicts = []
        for col in cols:
            col_conflicts.append(col.total_conflict(n, conflicts))
        min_col = col_conflicts.index(min(col_conflicts))
        cols[min_col].neurons.append(n)


    p = Placement(num_cols)
    for (i, col) in enumerate(cols):
        for neuron in col.neurons:
            p.assign_col(neuron, i)
    return p

def place_randomly(graph,num_columns, print_rows=True):
    p = Placement(num_columns)

    # Come up with a completely random col placement
    cols = list(range(num_columns))
    for entry in graph:
        p.assign_col(entry.node, random.choice(cols))
    for entry in graph:
        p.populate_for_input_neuron(entry.adjacent)

    if print_rows:
        p.print_rows()
    print('Random Placement Final number of rows:', p.get_row_num())


def place_initially(graph, num_columns, print_rows=False):
    total_length = 0

    for entry in graph:
        column_counts = [0] * num_columns

        for connection in entry.adjacent:
            column = connection % num_columns
            column_counts[int(column)] += 1

        ##print('Neuron idx %d' % entry.node, column_counts)
        total_length += max(column_counts)
    print("Initial_Placement Final Number of Rows",  total_length)
    return total_length
    
def get_final_length(graph, mapping):
    total_length = 0

    for entry in graph:
        column_counts = [0] * 8

        for connection in entry:
            connection = mapping[connection]
            column = connection % 8
            column_counts[column] += 1

        ##print('Neuron idx %d' % entry.node, column_counts)
        total_length += max(column_counts)
    print("FinallyFinal Final Number of Rows", total_length)

def replace_graph(graph, placement):
    placement.fill_columns()
    mapping = placement.create_mapping()
    reversed_mapping = {v: k for k, v in mapping.items()}
    graph = [entry.adjacent for entry in graph]
    l = len(graph)
    print('Column Lengths: ', placement.get_column_lengths())
    print('test', reversed_mapping[0])
    print(graph[12])
    print('hyi', graph[reversed_mapping[0]])
    print('hyi', [mapping[i] for i in graph[reversed_mapping[0]]])

    graph = [graph[reversed_mapping[i]] if reversed_mapping[i] < l else [] for i in range(len(mapping))]
    new_placement = Placement(8)
    for i in range(placement.num_cols):
        for j in placement.column_map[i].neurons:
            new_placement.column_map[i].neurons.append(mapping[j])
            new_placement.neuron_map[mapping[j]] = i

    for row in range(len(graph)):
        new_row = []
        for entry in range(len(graph[row])):
            new_row.append(mapping[graph[row][entry]])
        graph[row] = new_row

    graph = [AdjListEntry(i, graph[i]) for i in range(len(graph))]
    for entry in graph:
        new_placement.populate_for_input_neuron(entry.adjacent)

    return new_placement

def place_algorithmically(graph, num_columns, print_rows=True):
    print("Characterizing conflicts")
    conflicts, global_conflicts = characterize_conflicts(graph)
    print(len(global_conflicts))
    print("Creating placement")
    placement = create_placement(conflicts, global_conflicts, num_columns)

    print("Populating rows")
    for entry in graph:
        placement.populate_for_input_neuron(entry.adjacent)

    if print_rows:
        placement.print_rows(length=5)

    print('Algorithmic Placement Final number of rows:', placement.get_row_num())

    #new_placement = replace_graph(graph,placement)

    #if print_rows:
    #    new_placement.print_rows(length=5)

    #print('Column Lengths: ',new_placement.get_column_lengths())

    #print('Algorithmic Placement Final number of rows (Rearranged):', new_placement.get_row_num())
    
    return placement.get_row_num()

def main():
    num_columns = 4 
    for i in [64, 128, 256, 512]:
#    for i in [10, 50, 100, 256]:
#    for i in [2]:
        print("___________________________________________")
 
        print("i = %d"%(i))
        print('Placing 10000 Neurons')
        random.seed(100)
        graph = create_random_data(1000, i)
        #graph = load_data_2('small_world/small_world_10000_' + str(i) + '_0.5.pkl')
        #graph  = load_data_2('hier_files/hier_network_8_4_1000_0.01_0.pkl')
        for i in range(5):
            print(graph[i])
        
        n1 = place_initially(graph, num_columns)
        place_randomly(graph, num_columns, print_rows=False) # 118547
        n2 = place_algorithmically(graph, num_columns ,print_rows=False)  # 80498
        
        print(n2/n1)

if __name__ == "__main__":
    main()

