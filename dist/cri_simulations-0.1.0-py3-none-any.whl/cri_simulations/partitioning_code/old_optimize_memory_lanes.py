import random
from collections import defaultdict
import numpy as np
import networkx as nx


def create_scale_free_data(n_rows=5000):
	data = []
	G = nx.watts_strogatz_graph(n_rows,50,0.5)
	for node in G.nodes():
		nodes = []
		for edge in G.edges(node):
#			print(edge)
			nodes.append((edge[1], random.uniform(-1,1)))
#		print('_______________')
		data.append(nodes)
#	print(data[100])
	return data



def create_random_data(n_rows = 10):
	data = []
	avg_connections = random.randint(0,256)

	for row in range(n_rows):
		row_data = []
		for connection in range(avg_connections):
			weight = random.uniform(-1,1)
			row_data.append((random.randint(0,n_rows-1), weight)) 

		data.append(row_data)

	return data
	
def stochastic_optimization(data,num_lanes):
	new_idxs = list(range(len(data)))

	random.shuffle(new_idxs)

	mapping = {}

	for idx in range(len(new_idxs)):
		mapping[idx] = new_idxs[idx]

	data = [data[i] for i in new_idxs]
	# Replace the connections
	for row in range(len(data)):
		new_connections = []
		for connection in range(len(data[row])):
			addr, weight = data[row][connection]
			new_connections.append((mapping[addr], weight))

		data[row] = new_connections

	return data


# Optimizes by sorting by incoming connections
def optimize_memory_lanes(data, num_lanes):
	connection_dict = {key: 0 for key in list(range(len(data)))}

	#get number of incoming connections to each neuron
	for row in data:
		for addr,weight in row:
			connection_dict[addr] += 1
	
	sorted_keys = sorted(connection_dict.items(), key = lambda item: item[1], reverse = True)
	print('___________________________')
	
	# Create a zero list for each of the lanes
	incoming_connections = [0] * num_lanes 

	new_placements = [[] for i in range(num_lanes)]
	

	#Pop off the sorted_keys, add to the connection with the minimum elements

	while(len(sorted_keys) != 0):
		neuron_idx, num_connections = sorted_keys.pop(0)
		
		min_val = min(incoming_connections)
		min_location =  incoming_connections.index(min_val)
		
		incoming_connections[min_location] += num_connections
		new_placements[min_location].append(neuron_idx)
	#print(new_placements)

	# Create a mapping from the old neuron idx to the new one

	mapping = {}
	for lane in range(len(new_placements)):
		for row in range(len(new_placements[lane])):
			mapping[new_placements[lane][row]] = row * num_lanes + lane
	
	# Replace the neuron locations in the array with the new index
	new_idxs = [mapping[i] for i in range(len(data))]
	#print(new_idxs)
	print([i for i in new_idxs if i >= len(data)])
	print('____________')
	data = [data[i] for i in new_idxs]

	# Replace the connections
	for row in range(len(data)):
		new_connections = []
		for connection in range(len(data[row])):
			addr, weight = data[row][connection]
			new_connections.append((mapping[addr], weight))
		
		data[row] = new_connections

	return data

def fast_evaluate_data(network, num_columns = 8):
	total_length = 0
	for row in range(len(network)):
		column_counts = [0] * num_columns

		for connection in network[row]:
			column = connection[0] % num_columns
			column_counts[column] += 1	
		
		print('Neuron idx %d' % row, column_counts)
		total_length += max(column_counts)		
	print(total_length)


# Does no optimization, merely plugs in a full row until the next row can be filled
def evaluate_data(network,DATA_PER_ROW=8):
        ptrs = []
        data = []
        current=0
        for neuron in range(len(network)):
            weights = network[neuron]
            used_weights = np.ones(len(weights))
            num_rows = 0
	
            # If there are no connections
            if not weights:
                data.append([(0,0,0) for r in range(DATA_PER_ROW)])
                ptrs.append((current, current))
                current += 1
                continue

            while(sum(used_weights) != 0):
                # Create a row
                row = np.zeros(DATA_PER_ROW).astype(object)

                for w in range(len(weights)):
                    if used_weights[w] != 0:
                        column = weights[w][0] % DATA_PER_ROW
                        if row[column] == 0:
                           row[column] = (0, np.floor(weights[w][0] / DATA_PER_ROW), weights[w][1])
                           used_weights[w] = 0

                row = [r if r != 0 else (0,0,0) for r in row]
                num_rows += 1 #For the pointers
                data.append(row)

            ptrs.append((current, current + num_rows - 1))
            current += num_rows

        data.append([(0, 0, 0) for r in range(DATA_PER_ROW)])
        return data	


def main():
	random.seed(2)
	data = create_random_data()
	#data = create_scale_free_data()
	#print(len(data))
	#print(len(data[0]))
	#print(data[0][:5])

	#optimized_data = optimize_memory_lanes(data,8)
	fast_evaluate_data(data,8)
	returned = evaluate_data(data)
	print('Length unoptimized_data: ', len(returned))
	#returned = evaluate_data(optimized_data)
	#print('Length optimized_data: ', len(returned))

	#for i in range(20):
#		random_returned = stochastic_optimization(data,8)
#		print(len(evaluate_data(random_returned)))
if __name__ == '__main__':
	main()
