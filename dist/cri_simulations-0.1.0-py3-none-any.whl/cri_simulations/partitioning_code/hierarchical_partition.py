import pickle
from cri_simulations.partitioning_code.estimate_hbm_v2 import new_estimate_hbm
from cri_simulations.partitioning_code.estimate_hbm_no_mask import estimate_hbm_no_mask
import time
import pymetis
from cri_simulations.partitioning_code.sample_network import generate_random_class_labels
import metis
import numpy as np
#from gen_small_world import create_small_world
import random
from cri_simulations.partitioning_code.get_adjacency import get_adjacency
from cri_simulations.partitioning_code.align_v2 import align, align_2
from cri_simulations.partitioning_code.gen_hier_network import create_network
from cri_simulations.partitioning_code.old_gen_hier_network import old_create_network
import cri_simulations.partitioning_code.balanced_kmeans

def convert_to_undirected(adj):
    new_adj = []
    counter = 0
    print("here")
    try:
        for i in range(len(adj)):
            for j in adj[i]:
                if i not in adj[j]:
                    counter += 1
                    adj[j] = np.append(adj[j],i)
    except IndexError as e:
        print(i,j)

    print("Number of edges filled: ", counter)

    return adj

def load_data(filename):
    with open(filename + '.pkl', 'rb') as f:
        data = pickle.load(f)
    adj = []

    # Create the adjacency list
    for i in range(len(data)):
        if isinstance(data[i], list):
            adj.append(np.array(data[i]).astype(int))
        else:
            adj.append(data[i].astype(int))

    print("LENGTH: ", len(adj))

    return adj


def create_adj(data):
    #with open(filename + '.pkl', 'rb') as f:
    #    data = pickle.load(f)
    adj = []

    # Create the adjacency list
    for i in range(len(data)):
        if isinstance(data[i], list):
            adj.append(np.array(data[i]).astype(int))
        else:
            adj.append(data[i].astype(int))

    print("LENGTH: ", len(adj))

    return adj

def partition(data,n_clusters):
    breakpoint()
    class_labels = {}
    dir_adj = create_adj(data)

    
    import os.path
    #force_create = False


    #if os.path.isfile(filename + "_undirected.pkl") and not force_create:
    #    print("Found the undirected version of the file")
    #    with open(filename + "_undirected.pkl", "rb") as f:
    #        adj = pickle.load(f)
    #else:
    print("Creating the Undirected version of this file")
    sum_dir_adj = sum([len(i) for i in dir_adj])
    adj = convert_to_undirected(dir_adj)
    sum_adj = sum([len(i) for i in adj])

    print(sum_adj, sum_dir_adj)
    #with open(filename + "_undirected.pkl", "wb") as f:
    #    pickle.dump(adj, f)


    print('started metis')
    #start = time.time()

    #n_cuts,membership = metis.part_graph(adj,n_clusters)
    n_cuts ,membership = pymetis.part_graph(n_clusters,adj)
    #end = time.time()
    
    print(len(membership))
    print('ended metis')

    for i in range(len(membership)):
        class_labels[i] = membership[i]

    print("MEMBERSHIP LENGTH: ", len(membership))
    #print("Total time: ", end - start)

    #with open(filename + '_partition.pkl', 'wb') as f:
    #    pickle.dump(class_labels, f)

    return class_labels


def estimate(filename,n_clusters,cluster_size, n_partitions, fpga_size = 32, old=False, randomize=False, mask=True):
    adj = load_data(filename)

    with open(filename + '_partition.pkl', 'rb') as f:
        class_labels = pickle.load(f)

    rands = list(range(n_partitions))
    print("randomized the metis output")
    if randomize:
        random.shuffle(rands)

        for key in class_labels:
            class_labels[key] = rands[class_labels[key]]
    
    with open(filename+'_randomized_partition.pkl','wb') as f:
        pickle.dump(class_labels,f)

    if mask:
        print('Results with METIS partitioning')
        f1,f2,f3 = new_estimate_hbm(adj, class_labels, cluster_size = cluster_size, fpga_size = fpga_size)
        print('Results with Random partitioning')
        random_labels = generate_random_class_labels(len(adj), n_partitions)
        r1,r2,r3 = new_estimate_hbm(adj ,random_labels, cluster_size = cluster_size, fpga_size = fpga_size)

    else:
        print('Results with METIS partitioning ( no mask)')
        f1,f2,f3 = estimate_hbm_no_mask(adj, class_labels, cluster_size = cluster_size, fpga_size = fpga_size)
  
        print('Results with Random partitioning')
        random_labels = generate_random_class_labels(len(adj), n_partitions)
        r1,r2,r3 = estimate_hbm_no_mask(adj ,random_labels, cluster_size = cluster_size, fpga_size = fpga_size)
    print('___________________________________________')

    return f1,f2,f3,r1,r2,r3

"""
def main():
    #for l in [0.001]:
    #for l in [0.001, 0.01, 0.1, 1]:
    #for l in [0.001]:
    #for l in [10000,100000,1000000]:
    #for l in [1000000]:
    breakpoint()
    for l in ["dnn"]:
    #    old_create_network(1000,8,4,0,l)
        results1 = [[],[],[],[],[],[],[],[],[]]
        results2 = [[],[],[],[],[],[],[],[],[]]
        #filename = 'hier_files/hier_network_8_4_1000_' + str(l) + '_8'

        filename = "hier_files/fly_brain"
        #filename = "asrnet/asrnet_final"
        #filename = "small_world/small_world_" + str(l) + "_256_0.5"
        
        for iters in range(1):

            n_partitions = 32
            fpga_size = 32
            magic_labels = partition(filename,n_clusters=n_partitions)
            breakpoint()
            f1,f2,f3,r1,r2,r3 = estimate(filename,n_clusters=4,cluster_size=8,n_partitions=n_partitions,fpga_size=fpga_size,randomize=True,mask=True)
            get_adjacency(filename)
            #h1,h2,h3 = align(filename, n=[8,4], mask = True)

            h1,h2,h3 = align_2(filename,fpga_size, n = [4], mask = True)

            results1[0].append(f1)
            results1[1].append(f2)
            results1[2].append(f3)
            results1[3].append(r1)
            results1[4].append(r2)
            results1[5].append(r3)
            results1[6].append(h1)
            results1[7].append(h2)
            results1[8].append(h3)
            
            #f1,f2,f3,r1,r2,r3 = estimate(filename,n_clusters=4,cluster_size=4,n_partitions=n_partitions,fpga_size=fpga_size,randomize=True,mask=False)
            #get_adjacency(filename)
            #h1,h2,h3 = align(filename, n = [8,4], mask = False)

            #h1,h2,h3 = align_2(filename,fpga_size, n = [4], mask = False)
            
            #results2[0].append(f1)
            #results2[1].append(f2)
            #results2[2].append(f3)
            #results2[3].append(r1)
            #results2[4].append(r2)
            #results2[5].append(r3)
            #results2[6].append(h1)
            #results2[7].append(h2)
            #results2[8].append(h3)

        
        print("Results: WITH MASK and l = %s"%(str(l)))
        for i in results1:
            print(i, np.mean(i), np.std(i))
        #print("Results: WITH NO MASK and l = %s"%(str(l)))
        #for i in results2:
        #    print(i,np.mean(i), np.std(i))
    
        with open ("results_%s_%s"%(str(l), str(True)) + ".pkl", "wb") as f:
            pickle.dump(results1,f)
            
        #with open ("results_%s_%s"%(str(l), str(False)) + ".pkl", "wb") as f:
        #    pickle.dump(results2,f)

if __name__ == '__main__':
    main()
"""
