import numpy as np
import random
import matplotlib.pyplot as plt
import pickle

def get_k(l, m0, m1, m2,m3 = None):
        if not m3:
            return (1/(m0 + m1 * l + m2 * l**2))
        return (1/(m0 + m1 * l + m2 * l**2 + m3 * l**3))

def generate_pdf(index, npc, cores_per_cluster, clusters_per_fpga, n_fpgas_per_server = None, l = 0.01):
        neurons = npc * cores_per_cluster * clusters_per_fpga
            
        k = get_k(l,npc,npc*(cores_per_cluster - 1),npc * cores_per_cluster *(clusters_per_fpga - 1), npc * cores_per_cluster * clusters_per_fpga * (n_fpgas_per_server -1 ) )


        p_internal = k
        p_cluster = k * l
        p_fpga = k * l**2
        p_server = k * l**3
                                
                                    
        pdf = []
        for s in range(n_fpgas_per_server):
            for f in range(clusters_per_fpga):
                for c in range(cores_per_cluster):
                    idx = s * (cores_per_cluster * clusters_per_fpga) + f*cores_per_cluster + c
                                                                                    
                    # Same index
                    if (idx == index):
                        pdf += [p_internal] * npc
                                                                                                                                    
                    # Same cluster
                    elif int(idx/8) == int(index/8):
                        pdf += [p_cluster] * npc
                                                                                                                                                                                                                                                                 # Off cluster
                    elif int(idx/32) == int(index/32):
                        pdf += [p_fpga] * npc
                    else:
                        pdf += [p_server] * npc
                        
        
        return pdf


def randomize(adj):
    random.seed(2)
    indeces = list(range(len(adj)))
    random.shuffle(indeces)

    old_to_new_map = {}
    for i in range(len(indeces)):
        old_to_new_map[i] = indeces[i]

    new_to_old_map = {v: k for k, v in old_to_new_map.items()}
    new_adj = []

    for i in range(len(indeces)):
        index = new_to_old_map[i]
        new_row = np.array([])
        for j in adj[index]:
            new_row = np.append(new_row,old_to_new_map[j]).astype(int)

        new_adj.append(new_row)

    return new_adj


def gen_network(num_groups, npc, cores_per_cluster, clusters_per_fpga, fpgas_per_server, l):
        nodes = []
            
        for group_idx in range(num_groups):
            pdf = generate_pdf(group_idx, npc, cores_per_cluster, clusters_per_fpga, fpgas_per_server, l)
            
            if group_idx % 5 == 0:
                print(group_idx)

            for neuron in range(npc):
                num_connections = random.randint(0,512)
                connex = np.random.choice(npc * cores_per_cluster * clusters_per_fpga * fpgas_per_server, num_connections, p=pdf,replace=False)
                nodes.append(connex.astype(int))
                                                                                                        
        return nodes

#neurons_per_core = [1000]
#cores_per_cluster = 8
#clusters_per_fpga = 4
#fpgas_per_server = 2

#num_nodes = cores_per_cluster * clusters_per_fpga * fpgas_per_server
#l = [0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009]

#l = [0.001, 0.01]
def quick_eval(adj):
    
    counter = 0
    for i in range(len(adj)):
        for j in adj[i]:
            if i < 32000 and j >= 32000:
                counter += 1
            elif i >= 32000 and j < 32000:
                counter += 1

    return counter

def create_network(neurons_per_core, cores_per_cluster, clusters_per_fpga, fpgas_per_server, l):
    num_nodes = cores_per_cluster * clusters_per_fpga * fpgas_per_server
    adj = gen_network(num_nodes, neurons_per_core, cores_per_cluster, clusters_per_fpga, fpgas_per_server, l)
        
    adj = randomize(adj)
    print("eval results: ", quick_eval(adj))

    with open ('hier_files/hier_network_8_4' + '_' + str(neurons_per_core) + '_' + str(l)  + "_" + str(fpgas_per_server) +  '.pkl', 'wb') as f:
        pickle.dump(adj,f)
            
