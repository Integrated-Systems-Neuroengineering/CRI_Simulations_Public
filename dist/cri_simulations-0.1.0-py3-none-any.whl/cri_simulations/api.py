#from .compile_network import compileNetwork
#from .FPGA_Execution.fpga_compiler import *
#from .FPGA_Execution.fpga_controller import *
from cri_simulations.network import *




